USE [master]
GO

/****** Object:  Database [newtest]    Script Date: 03/24/2018 21:06:29 ******/
CREATE DATABASE [newtest] 
go



USE [newtest]
GO

/****** Object:  Table [dbo].[Zhuanjia_table]    Script Date: 03/24/2018 21:07:45 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[Zhuanjia_table](
	[zhuanjia_user] [char](10) NOT NULL,
	[zhuanjia_name] [char](10) NULL,
	[zhuanjia_sex] [nchar](2) NULL,
	[zhuanjia_logindate] [date] NULL,
	[zhuanjia_pwd] [char](15) NULL,
 CONSTRAINT [PK_Zhuanjia_table] PRIMARY KEY CLUSTERED 
(
	[zhuanjia_user] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

INSERT INTO [newtest].[dbo].[Zhuanjia_table]
           ([zhuanjia_user]
           ,[zhuanjia_name]
           ,[zhuanjia_sex]
           ,[zhuanjia_logindate]
           ,[zhuanjia_pwd])
     VALUES
           ('Zj2018001','���ΰ�','��','2018-03-15','123456'),
           ('Zj2018002','����','Ů','2018-03-15','123456'),
           ('Zj2018003','����','��','2018-03-15','123456')
GO
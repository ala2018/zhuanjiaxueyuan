package com.Bean;

public class ZhuanjiaBean {
     private String zhuanjia_user;
     private String zhuanjia_name;
     private String zhuanjia_sex;
     private String zhuanjia_logindate;
     private String zhuanjia_pwd;
	public ZhuanjiaBean() {
		super();
	}
	public String getZhuanjia_pwd() {
		return zhuanjia_pwd;
	}
	public void setZhuanjia_pwd(String zhuanjia_pwd) {
		this.zhuanjia_pwd = zhuanjia_pwd;
	}
	public String getZhuanjia_user() {
		return zhuanjia_user;
	}
	public void setZhuanjia_user(String zhuanjia_user) {
		this.zhuanjia_user = zhuanjia_user;
	}
	public String getZhuanjia_name() {
		return zhuanjia_name;
	}
	public void setZhuanjia_name(String zhuanjia_name) {
		this.zhuanjia_name = zhuanjia_name;
	}
	public String getZhuanjia_sex() {
		return zhuanjia_sex;
	}
	public void setZhuanjia_sex(String zhuanjia_sex) {
		this.zhuanjia_sex = zhuanjia_sex;
	}
	public String getZhuanjia_logindate() {
		return zhuanjia_logindate;
	}
	public void setZhuanjia_logindate(String zhuanjia_logindate) {
		this.zhuanjia_logindate = zhuanjia_logindate;
	}
}
